<?php

namespace Piggly\WooPixGateway\Vendor\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
